# ADORE Runtime Bundle

Version: 1.0.0

This bundle contains only the files needed to run ADORE as a Python package.
It intentionally excludes tests, worktrees, .adore state, caches, and .venv.

Prepare:

```bash
uv sync --frozen
cp config.example.toml config.toml
${EDITOR:-vi} config.toml
```

Ubuntu service-style setup:

```bash
bash deploy/install-ubuntu.sh
bash deploy/install-ubuntu.sh --service
```

Windows service-style setup:

```powershell
.\deploy\install-windows.ps1 -NoTask
.\deploy\install-windows.ps1
```

Secrets belong in .env beside this file or in host CLI authentication.
The package never includes .env.
