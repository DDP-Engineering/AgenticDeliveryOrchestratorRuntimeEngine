﻿# ADORE Runtime Bundle

Version: 1.0.0

This bundle contains only the files needed to run ADORE as a Python package.
It intentionally excludes tests, worktrees, .adore state, caches, and .venv.

Prepare:

```powershell
uv sync --frozen
copy config.example.toml config.toml
notepad config.toml
```

Windows service-style setup:

```powershell
.\deploy\install-windows.ps1 -NoTask
.\deploy\install-windows.ps1
```

Ubuntu service-style setup:

```bash
bash deploy/install-ubuntu.sh
bash deploy/install-ubuntu.sh --service
```

Secrets belong in `.env` beside this file or in host CLI authentication.
The package never includes `.env`.
