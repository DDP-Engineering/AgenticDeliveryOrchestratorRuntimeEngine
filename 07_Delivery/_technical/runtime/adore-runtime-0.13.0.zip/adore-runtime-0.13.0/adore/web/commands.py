#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# Copyright (c) 2026 DDP Engineering
# This software is licensed under the PolyForm Noncommercial License 1.0.0.
# Commercial use requires a separate commercial license.
# See the LICENSE.txt file for full license details.
# SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
# -----------------------------------------------------------------------------
"""
@file commands.py
@brief Single-host durable web operation worker.
@details Uses the existing CLI as the bounded, locked engine boundary. A
         stopped worker marks in-flight commands uncertain instead of replaying
         a possible forge or container side effect.
"""

from __future__ import annotations

# IMPORTS
import argparse
from collections.abc import Callable
import os
from pathlib import Path
import subprocess
import sys
from threading import Event, Thread
import time

from adore.config import load_config, validate_config
from adore.polling import PollCadence
from adore.profiles import ProfileError, ProfileStore
from adore.state import StateError, StateStore
from adore.util import in_quiet_hours
from adore.web.image_build import ImageBuildError, ImageBuildService
from adore.web.store import WebStore, WebStoreError

# DATA MODELS / TYPEDEFINITIONS
Runner = Callable[[list[str], dict[str, str]], int]


# HELPER FUNCTIONS
def _run(argv: list[str], env: dict[str, str]) -> int:
    """@brief Run a fixed CLI argument vector with a finite timeout."""
    try:
        result = subprocess.run(
            argv, env=env, capture_output=True, text=True,
            check=False, timeout=21600,
        )
    except subprocess.TimeoutExpired:
        return 124
    return result.returncode


# PUBLIC API
class CommandWorker:
    """@brief Execute authorized persisted commands through ADORE's CLI."""

    def __init__(self, profiles: ProfileStore, web: WebStore,
                 runner: Runner = _run, *, image_runner=None) -> None:
        self.profiles = profiles
        self.web = web
        self.runner = runner
        self.environment = {**os.environ, "ADORE_HOME": str(profiles.home)}
        self.images = ImageBuildService(profiles, runner=image_runner)

    def run_pending(self) -> int:
        """@brief Execute at most one pending command; return 1 if claimed."""
        operation = self.web.claim_next()
        if operation is None:
            return 0
        actor = self.web.user_by_id(operation["actor_id"])
        project = operation["project"]
        try:
            grants = (self.web.memberships(actor["id"])
                      if actor is not None and actor["role"] != "admin" else set())
        except WebStoreError:
            self.web.finish(operation["id"], "failed", "project grants are corrupt")
            self.reject_image(operation)
            return 1
        if (actor is None or actor["disabled"] or not self.profiles.exists(project)
                or (actor["role"] != "admin" and project not in grants)):
            self.web.finish(operation["id"], "failed", "permission or project revoked")
            self.reject_image(operation)
            return 1
        try:
            profile = self.profiles.load(project)
            if profile.project_id != operation["project_id"]:
                self.web.finish(operation["id"], "failed", "project identity changed")
                self.reject_image(operation)
                return 1
            if operation["action"] == "delete":
                if actor["role"] != "admin" or not profile.archived:
                    self.web.finish(operation["id"], "failed",
                                    "delete requires an administrator and an archived project")
                    self.reject_image(operation)
                    return 1
            elif profile.archived:
                self.web.finish(operation["id"], "failed", "project archived")
                self.reject_image(operation)
                return 1
        except ProfileError:
            self.web.finish(operation["id"], "failed", "project metadata corrupt")
            self.reject_image(operation)
            return 1
        argv = [sys.executable, "-m", "adore", "--profile", project]
        action = operation["action"]
        target = operation["run_id"]
        if action == "image-build":
            self.web.finish(operation["id"], "failed", "environment managed externally")
            self.reject_image(operation)
            return 1
        if action == "cancel":
            try:
                profile = self.profiles.load(project)
                state = StateStore(
                    profile.store_root or self.profiles.default_store_root(project)
                )
                run = state.load(target)
            except (ProfileError, FileNotFoundError, StateError, OSError):
                self.web.finish(operation["id"], "failed", "run is unavailable")
                return 1
            if run.lifecycle == "cancelled":
                self.web.finish(operation["id"], "succeeded", "run cancelled")
                return 1
            if run.lifecycle in ("done", "failed", "handoff-pending", "handed-off"):
                self.web.finish(operation["id"], "failed", "run already finished")
                return 1
        if action == "delete" and target in ("", "remove-clone"):
            # The delete target carries only the explicit clone-removal choice.
            argv = [sys.executable, "-m", "adore", "profile", "delete", project,
                    "--force", "--remove-resources", *(["--remove-clone"] if target else [])]
        elif action == "start" and target.isdigit() and int(target) > 0:
            argv.extend(["run", "--once", "--ticket", target])
        elif action in ("retry", "cancel") and target:
            argv.extend([action, target])
        elif action in ("pause", "resume") and actor["role"] == "admin" and not target:
            argv.append(action)
        else:
            self.web.finish(operation["id"], "failed", "invalid operation")
            return 1
        try:
            code = self._run_with_cancel_watch(argv)
        except Exception:  # noqa: BLE001 - unexpected outcome needs reconciliation
            self.web.finish(operation["id"], "uncertain", "worker invocation failed")
            return 1
        if type(code) is not int:
            self.web.finish(operation["id"], "uncertain", "invalid engine outcome")
            return 1
        status = "uncertain" if code == 124 else "succeeded" if code == 0 else "failed"
        result = (
            "completed" if code == 0 else
            "outcome uncertain" if code == 124 else "engine rejected operation"
        )
        self.web.finish(operation["id"], status, result)
        if action == "delete" and status == "succeeded":
            self.web.audit(actor["id"], "project-deleted", project)
        return 1

    def reject_image(self, operation: dict) -> None:
        """@brief Mark a revoked queued image artifact failed without runtime effects.
        @param[in] operation Identity-bound queue request whose authorization failed.
        """
        if operation["action"] != "image-build":
            return
        try:
            profile = self.profiles.load(operation["project"])
            if profile.project_id != operation["project_id"]:
                return
            value = self.images.store(profile.name).operation(operation["run_id"])
            if value["phase"] == "queued":
                self.images.set_phase(profile.name, value["id"], "failed",
                                      error="image_worker_rejected")
        except (ProfileError, ImageBuildError, OSError, ValueError):
            pass  # Corruption cannot grant authority; queue retains the failed outcome.

    def _signal_pending_cancels(self) -> None:
        """@brief Recheck grants before signalling any active conductor."""
        for operation in self.web.pending_cancels():
            project = operation["project"]
            actor = self.web.user_by_id(operation["actor_id"])
            if actor is None or actor["disabled"] or not self.profiles.exists(project):
                continue
            try:
                if actor["role"] != "admin" and project not in self.web.memberships(
                    actor["id"]
                ):
                    continue
                profile = self.profiles.load(project)
                if profile.project_id != operation["project_id"]:
                    continue
                state = StateStore(
                    profile.store_root or self.profiles.default_store_root(project)
                )
                state.request_cancel(operation["run_id"])
            except (WebStoreError, ProfileError, FileNotFoundError, StateError, OSError):
                # The claimed command will report the unavailable run or state.
                continue

    def _run_with_cancel_watch(self, argv: list[str]) -> int:
        """@brief Watch queued cancellations around one blocking engine command."""
        done = Event()

        def watch() -> None:
            """@brief Deliver pending cancel signals during a blocking CLI poll."""
            while not done.wait(0.2):
                try:
                    self._signal_pending_cancels()
                except WebStoreError:
                    # The main worker still handles queued operations afterward.
                    return

        watcher = Thread(target=watch, daemon=True)
        watcher.start()
        try:
            return self.runner(argv, self.environment)
        finally:
            done.set()
            watcher.join(timeout=2)

    def poll_project(self, project: str) -> int:
        """@brief Poll one project while watching for newly authorized cancels."""
        argv = [sys.executable, "-m", "adore", "--profile", project,
                "run", "--once"]
        return self._run_with_cancel_watch(argv)

    def run_forever(self, *, interval: float = 2.0,
                    heartbeat_interval: float = 2.0,
                    stop: Event | None = None) -> None:
        """@brief Own the local worker lock, heartbeat and project polling."""
        lock = StateStore(self.profiles.home / "web-control", "adore-web")
        if not lock.acquire_lock():
            raise RuntimeError("another web control worker is active")
        stop = stop or Event()
        heartbeat_done = Event()
        heartbeat_failed = Event()
        heartbeat_thread = None
        heartbeat_started = False

        def beat() -> None:
            """@brief Keep readiness current while a conductor call blocks."""
            while not heartbeat_done.wait(heartbeat_interval):
                try:
                    self.web.touch_worker()
                except (WebStoreError, OSError):
                    heartbeat_failed.set()
                    return

        next_poll: dict[str, float] = {}
        cadences: dict[str, PollCadence] = {}
        try:
            for operation in self.web.running_image_builds():
                try:
                    profile = self.profiles.load(operation["project"])
                    if profile.project_id == operation["project_id"]:
                        self.images.recover(profile.name, operation["run_id"])
                except (ProfileError, ImageBuildError, OSError, ValueError):
                    pass  # No authority from corrupt/replaced profiles; evidence stays uncertain.
            self.web.recover_interrupted()
            self.web.touch_worker()
            heartbeat_started = True
            heartbeat_thread = Thread(target=beat, daemon=True)
            heartbeat_thread.start()
            while not stop.is_set():
                if heartbeat_failed.is_set():
                    raise RuntimeError("web control worker heartbeat failed")
                if self.run_pending():
                    continue
                active_profiles = [profile for profile in self.profiles.list_profiles()
                                   if not profile.archived]
                for profile in sorted(active_profiles,
                                      key=lambda item: next_poll.get(item.project_id, 0.0)):
                    identity = profile.project_id
                    if next_poll.get(identity, 0.0) > time.monotonic():
                        continue
                    cadence = cadences.setdefault(identity, PollCadence())
                    try:
                        config = load_config(self.profiles.config_path(profile.name))
                        if validate_config(config):
                            raise ValueError("invalid project configuration")
                        # Validate cadence before invoking external work, without
                        # consuming a jitter sample or changing this project's state.
                        PollCadence.validate(config.polling)
                    except (OSError, ValueError, TypeError, AttributeError):
                        next_poll[identity] = time.monotonic() + 60
                        continue
                    failed = None
                    if not in_quiet_hours(config.polling.quiet_hours):
                        try:
                            code = self.poll_project(profile.name)
                            failed = type(code) is not int or code != 0
                        except Exception:  # noqa: BLE001 - a failed pass must not stop scheduling
                            failed = True
                    delay = cadence.next_delay(config.polling, failed=failed)
                    next_poll[identity] = time.monotonic() + delay
                    break
                deadlines = [next_poll.get(item.project_id, 0.0) for item in active_profiles]
                wait = (min(interval, max(0.0, min(deadlines) - time.monotonic()))
                        if deadlines else interval)
                stop.wait(wait)
        finally:
            heartbeat_done.set()
            if heartbeat_thread is not None:
                heartbeat_thread.join(timeout=heartbeat_interval + 1)
            try:
                if heartbeat_started:
                    self.web.clear_worker()
            finally:
                lock.release_lock()


def main() -> int:
    """@brief Launch the web control worker."""
    parser = argparse.ArgumentParser(description="ADORE web control worker")
    parser.add_argument("--home", type=Path, default=None)
    args = parser.parse_args()
    profiles = ProfileStore(args.home)
    CommandWorker(profiles, WebStore(profiles.home / "web.db")).run_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


# END OF FILE
