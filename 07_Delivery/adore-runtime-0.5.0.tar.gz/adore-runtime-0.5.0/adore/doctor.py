#!/usr/bin/env python3
# -*- coding: utf-8 -*-  # noqa: UP009
# -----------------------------------------------------------------------------
# Copyright (c) 2026 DDP Engineering
# This software is licensed under the PolyForm Noncommercial License 1.0.0.
# Commercial use requires a separate commercial license.
# See the LICENSE.txt file for full license details.
# SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
# -----------------------------------------------------------------------------
"""
@file doctor.py
@brief Environment detection + prerequisite guidance for assisted setup
       (Assisted_Config_And_Profiles_Plan, task 2).
@details The data/text layer beneath the `adore init` wizard (task 3) and a
         future `adore doctor` command. It PROBES the host for the tools ADORE
         needs - git, a container runtime (docker/podman, optionally inside
         WSL), the platform CLI (glab/gh/tea) and its auth, the executor CLI -
         and
         returns typed results; and it supplies the exact, OS-specific
         install/setup instructions to print when something is missing. Every
         probe goes through the injectable CommandRunner (never a raw
         subprocess here), so the whole module is unit-testable offline with a
         fake runner; no prompting and no network calls of its own live here.
"""

from __future__ import annotations

# IMPORTS
from dataclasses import dataclass, field
import json
from pathlib import Path
import platform
import re

from adore.util import CommandRunner, run_command

# CONSTANTS

# Component keys for guidance_for(); also the tool names probed.
GIT = "git"
DOCKER = "docker"
PODMAN = "podman"
WSL = "wsl"
GLAB = "glab"
GH = "gh"
TEA = "tea"
GLAB_AUTH = "glab-auth"
GH_AUTH = "gh-auth"
TEA_AUTH = "tea-auth"
OPENCODE = "opencode"
AEGIS = "aegis"

# The AEGIS 0.5 payload contract the target repository must satisfy.
AEGIS_WRAPPER = ".agentic/aegis.py"
AEGIS_SCHEMA_VERSION = 1
AEGIS_VERSION_RE = re.compile(r"aegis\s+0\.5\.\d+\Z")

# Platform-CLI + auth mapping by platform kind.
_CLI_FOR_KIND = {"gitlab": GLAB, "github": GH, "gitea": TEA}
_AUTH_COMPONENT_FOR_KIND = {"gitlab": GLAB_AUTH, "github": GH_AUTH, "gitea": TEA_AUTH}
# Auth probe argv by kind. Kind-specific on purpose: tea has no `auth status`
# subcommand - and tea exits 0 for UNKNOWN subcommands ("No help topic"), so a
# generic `<cli> auth status` would falsely report Gitea as authenticated.
# `tea whoami` calls the API with the stored token, which is the real check.
_AUTH_PROBE_FOR_KIND = {
    "gitlab": (GLAB, "auth", "status"),
    "github": (GH, "auth", "status"),
    "gitea": (TEA, "whoami"),
}

# OS-specific (and a "*" generic) install/setup text. Kept as data so the
# wizard and `adore doctor` render identical instructions.
GUIDANCE: dict[str, dict[str, str]] = {
    GIT: {
        "windows": "Install Git for Windows: `winget install Git.Git` "
                   "(or https://git-scm.com/download/win).",
        "linux": "Install git: `sudo apt-get update && sudo apt-get install -y git`.",
    },
    DOCKER: {
        "windows": "Enable WSL2 (`wsl --install`), then install Docker Engine "
                   "INSIDE the distro (no Docker Desktop needed) and set the "
                   "runtime to `wsl -d <distro> -- docker`.",
        "linux": "Install Docker Engine: "
                 "https://docs.docker.com/engine/install/ubuntu/ .",
    },
    PODMAN: {
        "windows": "Install podman inside your WSL2 distro: "
                   "`sudo apt-get install -y podman uidmap slirp4netns`; use the "
                   "runtime `wsl -d <distro> -- podman` with "
                   'run_args=["--userns=keep-id"].',
        "linux": "Install podman: "
                 "`sudo apt-get install -y podman uidmap slirp4netns`; rootless "
                 'podman needs run_args=["--userns=keep-id"].',
    },
    WSL: {
        "windows": "Install WSL2: `wsl --install`; then install a distro (e.g. "
                   "Ubuntu-24.04) and a container runtime inside it.",
        "linux": "(WSL is a Windows feature; not applicable on Linux.)",
    },
    GLAB: {
        "windows": "Install the GitLab CLI: `winget install GLab.GLab` "
                   "(or `scoop install glab`).",
        "linux": "Install the GitLab CLI: download the .deb from the glab "
                 "releases page and `sudo apt-get install ./glab_*.deb` "
                 "(or `sudo apt-get install glab` where packaged).",
    },
    GH: {
        "windows": "Install the GitHub CLI: `winget install GitHub.cli`.",
        "linux": "Install the GitHub CLI: see "
                 "https://github.com/cli/cli/blob/trunk/docs/install_linux.md .",
    },
    GLAB_AUTH: {
        "*": (
            "Create a GitLab Personal Access Token: GitLab -> your avatar -> "
            "Preferences -> Access Tokens -> Add new token; scope `api`; role "
            "Developer (Developer cannot merge protected branches - intended, "
            "ADORE never merges). Copy it now (shown once). A GitLab PAT looks "
            "like `glpat-XXXXXXXXXXXXXXXXXXXX` (the prefix `glpat-` followed by "
            "20 characters). Then authenticate the CLI: `glab auth login` (for a "
            "corporate instance choose the hostname, e.g. gitlab.mycorp.fr, and "
            "paste the token). Alternatively set GITLAB_TOKEN in the project "
            ".env - the wizard records the key NAME, never the value."
        )
    },
    GH_AUTH: {
        "*": (
            "Create a fine-grained GitHub Personal Access Token with Contents + "
            "Pull requests + Issues (read/write), then run `gh auth login` and "
            "paste it. Alternatively set GITHUB_TOKEN in the project .env - the "
            "wizard records the key NAME, never the value."
        )
    },
    TEA: {
        "windows": "Install the Gitea CLI: download tea from "
                   "https://dl.gitea.com/tea/ (rename to tea.exe) and put it "
                   "on PATH.",
        "linux": "Install the Gitea CLI: download tea from "
                 "https://dl.gitea.com/tea/ and put it on PATH "
                 "(or `go install code.gitea.io/tea@latest`).",
    },
    TEA_AUTH: {
        "*": (
            "Create a Gitea access token: Gitea -> Settings -> Applications -> "
            "Generate New Token, with read/write on repository and issue "
            "(ADORE never merges; no admin scopes). Then register the login: "
            "`tea login add --name <name> --url http://<host>:<port> --token "
            "<token>` and make it the default (`tea logins default <name>`) or "
            "set `[platform] login = \"<name>\"` in the profile config."
        )
    },
    OPENCODE: {
        "*": (
            "opencode is baked into the executor base image, so you only need "
            "it on the HOST for the `host` runtime. Build the base and any "
            "runtime-project image per docker/README.md."
        )
    },
    AEGIS: {
        "*": (
            "The target repository must carry the current AEGIS 0.5.x payload "
            "with `.agentic/aegis.py` and JSON schema 1. Install the payload in "
            "the target clone without changing its source, then re-run `adore "
            "doctor`. ADORE 0.5 speaks only the AEGIS 0.5 companion CLI and has "
            "no AEGIS 3.x compatibility or migration path."
        )
    },
}

# DATA MODELS / TYPEDEFINITIONS


@dataclass
class ToolStatus:
    """
    @brief   Whether one CLI tool is present, and its reported version.
    """

    name: str
    present: bool
    version: str = ""
    detail: str = ""


@dataclass
class AuthStatus:
    """
    @brief   Whether the platform CLI is present AND authenticated.
    """

    kind: str            # gitlab | github | gitea
    cli: str             # glab | gh | tea
    present: bool
    authenticated: bool
    detail: str = ""


@dataclass
class RuntimeDetection:
    """
    @brief   Host container-runtime availability (+ WSL distros on Windows).
    """

    docker: ToolStatus
    podman: ToolStatus
    wsl_distros: list[str] = field(default_factory=list)


@dataclass
class AegisStatus:
    """
    @brief   Whether a target repository carries a usable AEGIS 0.5 payload.
    @details The Python companion CLI must exist, report version 0.5.x, and
             return a valid schema-1 status-list payload with no unreadable
             journals. `detail` carries the bounded failure reason.
    """

    repo_path: str
    wrapper_present: bool
    config_valid: bool
    schema_version: int | None = None
    version: str = ""
    detail: str = ""

    @property
    def ok(self) -> bool:
        """
        @brief   True when the repository is governed by usable AEGIS 0.5.x.
        @return  Readiness flag.
        """
        return (
            self.wrapper_present
            and self.config_valid
            and self.schema_version == AEGIS_SCHEMA_VERSION
        )


@dataclass
class EnvironmentReport:
    """
    @brief   Aggregate of every probe, for the wizard and `adore doctor`.
    """

    os_key: str
    git: ToolStatus
    runtimes: RuntimeDetection
    platform_cli: ToolStatus
    auth: AuthStatus
    executor: ToolStatus


# HELPER FUNCTIONS


def _os_key(system_name: str) -> str:
    """
    @brief      Normalize a platform.system() value to an ADORE OS key.
    @param[in]  system_name Raw platform name (e.g. "Windows", "Linux").
    @return     "windows" | "linux" | "macos" | "other".
    """
    name = system_name.strip().lower()
    if name.startswith("win"):
        return "windows"
    if name == "linux":
        return "linux"
    if name == "darwin":
        return "macos"
    return "other"


def _probe(runner: CommandRunner, name: str, argv: list[str]) -> ToolStatus:
    """
    @brief      Probe a tool via `<tool> --version` (or similar) through runner.
    @details    Exit 127 (binary missing, per run_command's convention) means
                absent; a clean exit yields the first stdout line as version; a
                present-but-erroring tool is reported present with a detail.
    @param[in]  runner Injectable command runner.
    @param[in]  name Component name (also the ToolStatus name).
    @param[in]  argv Command to run.
    @return     The ToolStatus.
    """
    result = runner(argv)
    if result.exit_code == 127:
        return ToolStatus(name=name, present=False, detail="not found on PATH")
    if result.ok:
        first = next((line.strip() for line in result.stdout.splitlines() if line.strip()), "")
        return ToolStatus(name=name, present=True, version=first)
    return ToolStatus(name=name, present=True, detail=(result.stderr.strip() or "error"))


# PUBLIC API


def detect_os() -> str:
    """
    @brief   The current host's ADORE OS key.
    @return  "windows" | "linux" | "macos" | "other".
    """
    return _os_key(platform.system())


def detect_git(runner: CommandRunner = run_command) -> ToolStatus:
    """
    @brief      Whether git is available on the host.
    @param[in]  runner Injectable command runner.
    @return     The ToolStatus for git.
    """
    return _probe(runner, GIT, ["git", "--version"])


def detect_wsl_distros(runner: CommandRunner = run_command) -> list[str]:
    """
    @brief      Installed WSL distro names (Windows only; else empty).
    @details    `wsl -l -q` emits UTF-16 on some hosts; run_command decodes as
                UTF-8, so null bytes are stripped and blank lines dropped before
                returning the names (robust to that quirk).
    @param[in]  runner Injectable command runner.
    @return     Distro names, or [] when WSL is absent.
    """
    result = runner(["wsl", "-l", "-q"])
    if result.exit_code == 127 or not result.ok:
        return []
    cleaned = result.stdout.replace("\x00", "").replace("﻿", "")
    return [line.strip() for line in cleaned.splitlines() if line.strip()]


def detect_runtimes(
    runner: CommandRunner = run_command, *, os_key: str | None = None
) -> RuntimeDetection:
    """
    @brief      Host container-runtime availability.
    @param[in]  runner Injectable command runner.
    @param[in]  os_key Host OS key (defaults to detect_os()); WSL distros are
                       only probed on Windows.
    @return     The RuntimeDetection.
    """
    key = os_key or detect_os()
    docker = _probe(runner, DOCKER, ["docker", "--version"])
    podman = _probe(runner, PODMAN, ["podman", "--version"])
    distros = detect_wsl_distros(runner) if key == "windows" else []
    return RuntimeDetection(docker=docker, podman=podman, wsl_distros=distros)


def detect_platform_cli(kind: str, runner: CommandRunner = run_command) -> ToolStatus:
    """
    @brief      Whether the platform CLI for this kind is present.
    @param[in]  kind "gitlab" (glab), "github" (gh) or "gitea" (tea).
    @param[in]  runner Injectable command runner.
    @return     The ToolStatus for glab/gh/tea.
    @exception  ValueError When kind is not gitlab/github/gitea.
    """
    cli = _CLI_FOR_KIND.get(kind)
    if cli is None:
        raise ValueError(f"unknown platform kind: {kind!r}")
    return _probe(runner, cli, [cli, "--version"])


def auth_status(kind: str, runner: CommandRunner = run_command) -> AuthStatus:
    """
    @brief      Whether the platform CLI is authenticated.
    @details    Runs the kind-specific probe (`glab auth status` /
                `gh auth status` / `tea whoami`): exit 127 = CLI missing;
                exit 0 = authenticated; otherwise present-but-not. The probe
                argv is per kind because tea has no `auth status` - and tea
                exits 0 even for unknown subcommands, which would fake success.
    @param[in]  kind "gitlab", "github" or "gitea".
    @param[in]  runner Injectable command runner.
    @return     The AuthStatus.
    @exception  ValueError When kind is not gitlab/github/gitea.
    """
    probe = _AUTH_PROBE_FOR_KIND.get(kind)
    if probe is None:
        raise ValueError(f"unknown platform kind: {kind!r}")
    cli = probe[0]
    result = runner(list(probe))
    if result.exit_code == 127:
        return AuthStatus(kind=kind, cli=cli, present=False, authenticated=False,
                          detail="CLI not installed")
    detail = (result.stderr.strip() or result.stdout.strip())
    return AuthStatus(kind=kind, cli=cli, present=True, authenticated=result.ok,
                      detail=detail)


def detect_aegis(
    repo_path: str | Path,
    runner: CommandRunner = run_command,
) -> AegisStatus:
    """
    @brief      Probe a target repository for a usable AEGIS 0.5.x payload.
    @details    Requires `.agentic/aegis.py`, exact `aegis 0.5.x` version
                output, and a schema-1 `status --all --json` document. ADORE
                refuses malformed output, unknown versions/schemas and any
                unreadable journal before ticket pickup.
    @param[in]  repo_path Local clone the runs are created from.
    @param[in]  runner Injectable command runner.
    @return     The AegisStatus.
    """
    root = Path(repo_path).expanduser()
    if not (root / AEGIS_WRAPPER).is_file():
        return AegisStatus(
            repo_path=str(root), wrapper_present=False, config_valid=False,
            detail=f"{AEGIS_WRAPPER} is missing",
        )
    version_result = runner(["python", AEGIS_WRAPPER, "--version"], cwd=str(root))
    version = version_result.stdout.strip()
    if version_result.exit_code == 127:
        return AegisStatus(
            repo_path=str(root), wrapper_present=True, config_valid=False,
            detail="python is not available to run the AEGIS companion CLI",
        )
    if not version_result.ok or AEGIS_VERSION_RE.fullmatch(version) is None:
        return AegisStatus(
            repo_path=str(root), wrapper_present=True, config_valid=False,
            version=version,
            detail=(version_result.stderr.strip() or version
                    or "AEGIS returned no version")[:400],
        )
    result = runner(
        ["python", AEGIS_WRAPPER, "status", "--all", "--json"], cwd=str(root)
    )
    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError:
        return AegisStatus(
            repo_path=str(root), wrapper_present=True, config_valid=False,
            version=version,
            detail=(result.stderr.strip() or result.stdout.strip()
                    or "the AEGIS companion CLI produced no JSON")[:400],
        )
    valid_shape = (
        result.ok
        and isinstance(payload, dict)
        and payload.get("command") == "status"
        and isinstance(payload.get("tasks"), list)
        and payload.get("unreadable") == []
    )
    if not valid_shape:
        detail = (result.stderr.strip() or str(payload))[:400]
        return AegisStatus(
            repo_path=str(root), wrapper_present=True, config_valid=False,
            version=version, detail=detail,
        )
    schema = payload.get("schema")
    return AegisStatus(
        repo_path=str(root), wrapper_present=True, config_valid=True,
        schema_version=schema if isinstance(schema, int) else None,
        version=version,
        detail="" if schema == AEGIS_SCHEMA_VERSION
        else f"status reports schema {schema!r}, ADORE 0.5 requires "
             f"schema {AEGIS_SCHEMA_VERSION}",
    )


def detect_executor(name: str = OPENCODE, runner: CommandRunner = run_command) -> ToolStatus:
    """
    @brief      Whether an executor CLI is present on the host.
    @param[in]  name Executor CLI name (default opencode).
    @param[in]  runner Injectable command runner.
    @return     The ToolStatus.
    """
    return _probe(runner, name, [name, "--version"])


def detect_all(kind: str, runner: CommandRunner = run_command) -> EnvironmentReport:
    """
    @brief      Run every probe once, for the wizard / a future `adore doctor`.
    @param[in]  kind Platform kind ("gitlab" | "github" | "gitea") for the
                     CLI/auth probes.
    @param[in]  runner Injectable command runner.
    @return     The aggregate EnvironmentReport.
    """
    key = detect_os()
    return EnvironmentReport(
        os_key=key,
        git=detect_git(runner),
        runtimes=detect_runtimes(runner, os_key=key),
        platform_cli=detect_platform_cli(kind, runner),
        auth=auth_status(kind, runner),
        executor=detect_executor(runner=runner),
    )


def auth_component_for_kind(kind: str) -> str:
    """
    @brief      The guidance component key for a platform kind's auth setup.
    @param[in]  kind "gitlab" | "github" | "gitea".
    @return     GLAB_AUTH / GH_AUTH / TEA_AUTH.
    @exception  ValueError When kind is not gitlab/github/gitea.
    """
    component = _AUTH_COMPONENT_FOR_KIND.get(kind)
    if component is None:
        raise ValueError(f"unknown platform kind: {kind!r}")
    return component


def guidance_for(component: str, os_key: str) -> str:
    """
    @brief      OS-specific install/setup text for a prerequisite component.
    @details    Components with a "*" entry share one instruction for all OSes
                (e.g. token creation); otherwise Windows gets its own text and
                every non-Windows OS falls back to the Linux instructions
                (the plan targets Windows + Ubuntu).
    @param[in]  component A component key (GIT, DOCKER, GLAB_AUTH, ...).
    @param[in]  os_key OS key from detect_os() / _os_key().
    @return     The guidance text (a helpful fallback for unknown components).
    """
    entry = GUIDANCE.get(component)
    if not entry:
        return f"(no setup guidance for {component!r}; see the project docs)"
    if "*" in entry:
        return entry["*"]
    key = "windows" if os_key == "windows" else "linux"
    return entry.get(key, entry.get("linux", ""))


# END OF FILE
