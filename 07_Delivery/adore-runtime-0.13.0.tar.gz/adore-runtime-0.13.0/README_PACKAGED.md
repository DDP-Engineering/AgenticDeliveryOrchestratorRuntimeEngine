# ADORE Runtime Bundle

Version: 0.13.0

This bundle contains only the files needed to run ADORE as a Python package.
It intentionally excludes tests, worktrees, .adore state, caches, and .venv.

Read [Documentation](Documentation/README.md) before deployment. It contains
the prerequisite, credential, configuration, operation, and recovery guides.
Start with the [runtime integration guide](Documentation/Integrating_A_Runtime_Project.md).

Prepare:

```bash
uv sync --frozen
cp config.example.toml config.toml
${EDITOR:-vi} config.toml
```

Ubuntu service-style setup:

```bash
bash deploy/install-ubuntu.sh
bash deploy/install-ubuntu.sh --service
```

Windows service-style setup:

```powershell
.\deploy\install-windows.ps1 -NoTask
.\deploy\install-windows.ps1
```

Authenticate `glab` or `gh` on the host for forge access. Put only executor
provider keys named by `[executor].env_keys` in `.env` beside this file.
The package never includes `.env`.
