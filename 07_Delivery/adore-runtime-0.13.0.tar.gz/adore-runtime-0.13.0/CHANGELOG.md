<!--
Copyright (c) 2026 DDP Engineering
This software is licensed under the PolyForm Noncommercial License 1.0.0.
Commercial use requires a separate commercial license.
See the LICENSE.txt file for full license details. SPDX-License-Identifier: LicenseRef-PolyForm-Noncommercial-1.0.0
-->

# Changelog

All notable changes to the Agentic Delivery Orchestrator & Runtime Engine are recorded here.
This project follows Keep a Changelog and Semantic Versioning.

## [Unreleased]

### Added

- **ADORE now watches the forge pipeline on a published draft and can repair
  it.** Each poll of an `in-review` run reads the verdict through the new
  `Forge.pipeline_status`, normalized to `success`, `failed`, `running`, `none`
  or `unknown`. GitLab reads it inline from the MR document; GitHub requests
  `statusCheckRollup` in a separate `gh pr view` call, so a gh that does not
  know the field cannot break the MR read the poll depends on; Gitea reads the
  pull for `head.sha` and then that commit's combined status. The method is
  contracted never to raise, because the poll is watching a run doing no code
  work: anything unreadable is `unknown`, which is silent.
- New `[review] on_pipeline_failure`, defaulting to `revise`, decides what a
  newly failed verdict does. `revise` starts a governed repair round on the
  same bounded path the revise label uses: a new AEGIS task on the same branch,
  earlier journals preserved, and the executor told that a green pipeline is
  part of this round's acceptance criteria. The round therefore still ends at
  strict validation and a **fresh human approval** before anything is pushed,
  so automatic repair never weakens the delivery gate and ADORE still never
  merges. `notify` posts one comment and waits for a human; `ignore` skips the
  read entirely for a repository with no CI.
- A repair round announces itself on the draft, so a reviewer watching the
  MR/PR learns why commits are about to arrive instead of seeing an unexplained
  push. The notice names the round number and how to opt out.
- Only a CHANGED verdict is a signal, and `pipeline_reported` is cleared when a
  revision starts, so a run waiting days is neither nagged on every poll nor
  repaired twice for one failure, and the pipeline a repair produces is judged
  on its own. Repairs and human-requested revisions share `max_review_rounds`,
  so a permanently red pipeline cannot loop; when the budget is spent the run
  keeps waiting in review with a comment saying so rather than being failed.

### Fixed

- **GitHub and GitLab could never open a draft MR/PR.** Before creating one,
  `_publish` probes for an adoptable MR/PR by branch. `gh pr view <branch>`
  reports a branch miss as `no pull requests found for branch`, and
  `glab mr view <branch>` as `no open merge request available for`; neither
  matched the adapters' not-found markers, so the probe raised instead of
  reporting "none yet". The run then failed as `MR_CREATE_FAILED` after the
  push and after a human had approved the candidate, and `adore retry` hit the
  same wall. Both adapters now recognise their CLI's branch-miss wording; a
  genuine transport or auth failure still raises, so ADORE never opens a
  duplicate on a bad read. Gitea was unaffected.
- **A parked run on a busy ticket never resumed.** GitHub and GitLab comment
  reads fetched a single page, which is the OLDEST 100 entries, so a human
  answer past that point was invisible and the run died on
  `CLARIFICATION_TIMEOUT`. GitLab hit the cap fastest because every ADORE label
  change adds a system note. Both adapters now walk pages to the end, as the
  Gitea adapter already did.
- **The revise loop read an empty review thread on GitHub and Gitea.** Both
  routed MR/PR comments through the issue surface only, so a reviewer who
  requested changes through "Review changes" left the revision executor nothing
  to act on and the round was spent on a blind revision. Both adapters now also
  read submitted review bodies and inline diff comments and merge all surfaces
  onto one timeline. GitLab already returned diff notes.
- **An unexpected error killed the poll loop instead of one run.** `run_loop`
  caught only `ForgeError`, so an `IsolationError` from a checkpoint commit, or
  a `KeyError` from an executor template carrying an unsupported brace, ended
  the process and stranded every waiting run; the next start then failed the
  in-flight run as `STALE_WORKING`. The loop now logs any unexpected error and
  continues with the configured backoff, while `KeyboardInterrupt` still stops
  it cleanly.
- **`run_command` let some OS errors escape.** Only `FileNotFoundError` and
  `TimeoutExpired` became a `CommandResult`; a `PermissionError` or a command
  line past the Windows 32767-character limit propagated raw, past every
  handler. Any `OSError` is now reported as exit code 126.
- **The stage prompt contradicted itself about stopping.** The autopilot
  override added for AEGIS 0.13's checkpoint default said "never stop at a
  stage-boundary checkpoint", while the closing paragraph said "stop after the
  current stage". Both are reconcilable, but only via a trailing qualifier, and
  a model resolving the conflict in favour of the louder, earlier instruction
  runs the whole task in one session. Autopilot now speaks only about who
  decides and never about how far to go, and the one-stage rule is its own
  paragraph giving the reason: the session boundary is what gives ADORE a
  checkpoint, a per-stage error budget, and the chance to hand back the last
  failure. Measured on the same model, repository and ticket shape: two
  run-aheads in three launches before, none in six after.
- **A launch that produced nothing inherited the previous stage's transcript.**
  The gate protocol cleared the questions file before each launch so its
  presence afterwards could only mean this launch wrote it, but never applied
  the same rule to the output and stderr streams. An executor exiting zero
  without writing therefore had the previous stage's transcript archived as its
  own evidence and its tokens re-counted against the cost budget. Observed live:
  a build attempt archived byte-identical design output under the same session
  id. The streams are now cleared with the questions file.
- **An executor that ran the whole task in one session lost all its work.** The
  stage guard is a pure function of two stage names, so a skipped stage and a
  task completed in a single launch produce the identical hop and were refused
  alike. The run failed terminally, `adore retry` replayed the same refusal, and
  the completed work sat uncommitted. A forward jump is now accepted when the
  durable journal carries a Log entry for every stage it crossed, recorded as
  `stages-run-ahead` rather than tolerated silently; a genuine skip leaves gaps
  and stays refused. Found in the GitHub pilot, where the same model ran ahead
  in two of three launches and never once in seven on Gitea.
- **A failed publication attempt made the next one fail differently.** Every
  fingerprint refuses a dirty worktree, which is right for the first entry into
  publication, where validation guarantees a clean tree. On the paths that
  re-enter afterwards - the `_publish` retry and the approval-freshness check in
  `retry` - a part-finished bookkeeping attempt leaves files touched, so both
  died terminally on a condition they could have cleared, and a failure budgeted
  for three attempts got one. Leftover work is now settled first. The baseline
  for the candidate-mutation guard is captured once when publication begins and
  reused, so settling cannot launder an unapproved product change into the
  baseline; the guard is stricter across retries, not weaker.
- **A transient push failure ended a fully validated run.** Found in the Gitea
  pilot: a one-off `remote: Failed to authenticate user` from a credential
  refresh hit `PUSH_FAILED`, which is terminal, discarding both the run's work
  and the human approval bound to that exact candidate. The identical command
  succeeded seconds later. Every fetch around the push already retried through
  `_transient`; the push did not, because it returns its outcome as data rather
  than raising. All three push sites now retry on the same bounded schedule. A
  genuine refusal, such as a protected branch or a non-fast-forward, still fails
  every attempt and ends the run loudly.
- **Strict verification ran twice on every successful run.** The
  validate-to-deliver transition verifies, then the next pass of the conduct
  loop reads the task back at deliver and verified again, re-running the whole
  check catalogue and every configured command. Six seconds on the pilot's toy
  suite, a doubled test suite on a real repository. Re-verification is now
  skipped only when the candidate hashes identically to the one the stored
  evidence describes. Recorded deviations are re-harvested from the task the
  loop already read, which the second verification pass had been providing by
  accident.
- **Tool-regenerated files counted as product mutation.** A target repository
  without matching `.gitignore` rules carries its own bytecode and tool caches
  in the candidate, and the delivery gate reruns the configured commands, which
  rewrites them. That could invalidate an approval a human had already given,
  for a file nobody edited. Bytecode and the common tool caches are now excluded
  from the product fingerprint only; they stay in the diff and in
  `changed_files`, because the candidate really does contain them. `adore init`
  additionally flags a target repository that has no `.gitignore`, since that is
  the root cause and only the repository's own rules can separate generated
  files from new source the executor wrote.
- **Gitea reported a pipeline as `running` for a repository with no CI.** Gitea
  answers `state: "pending"` with `total_count: 0` when nothing has reported on
  the commit, so a repository without CI read as a pipeline forever in progress.
  The status count now decides before the state does.
- **A mistyped clone path during `adore init` was misdiagnosed.** git run with
  a missing working directory fails as "no such file" on POSIX and WinError 267
  on Windows, so the new push-access probe reported a missing git binary or a
  raw OS code. It now names the directory that does not exist.
- **An executor command template could carry a placeholder nothing fills.** The
  launcher renders the template with `str.format`, so `{resume}` on a non-Codex
  executor, or a shell `${HOME}`, raised `KeyError` at gate time once per
  attempt until the stage budget was spent, with nothing pointing at the cause.
  Configuration validation now rejects unsupported and malformed placeholders
  at setup.
- **`run --once` tracebacked where `run --loop` recovered.** After the poll loop
  was taught to survive an unexpected fault, a single pass still exited with a
  raw traceback for the same cause. That is the mode cron and Task Scheduler
  call, so it now reports the error and exits nonzero like every other CLI
  failure.
- **A missing lifecycle label failed the first run in silence.** The forge
  write that fails at claim time is the same one that would carry the
  explanation, so nothing appeared on the ticket. The reason is now logged to
  the console and `adore.log`, and `Getting_Started.md` lists the nine labels
  that must exist in the repository before the first run.

### Changed

- The executor launcher no longer carries session-continuation machinery. The
  orchestrator always launched with an empty session and never stored one back,
  so the `--session` append, Codex's `resume --last` rewrite, the dead-session
  self-heal relaunch and the per-executor `_extract_session_id` hooks could
  never run; `GateRun.session_id` and the `session` argument are gone with
  them. Every gate was, and remains, a fresh executor session with the durable
  AEGIS journal as the resume authority. Codex's `{resume}` template slot is
  still accepted and always resolves to empty, so existing profiles keep
  working.
- `adore init` now probes host git push access with `git ls-remote` in the
  target clone. That credential is separate from the platform CLI login and was
  previously unverified until `_publish` reached the push, where a failure
  discarded an approval a human had already given.
- The AEGIS setup guidance pointed at `adore doctor`, a command the CLI does not
  implement; it now names `adore init <profile>`, which repeats the same probe.
- Documented that ADORE reads no forge pipeline, check-run or commit-status
  result, so a failing pipeline on a draft is a human decision point, and that
  `allowlist-proxy` egress needs Podman 4.0 or newer with netavark, since
  Podman 3.x with CNI cannot resolve the proxy alias on an internal network.

### Added

- The approval presentation now leads with the deviations the AEGIS task
  journal recorded: a count and the full text of every `DEVIATION <stage>`
  entry, harvested with the same marker rule AEGIS applies to its own delivery
  report and copied into the persisted validation evidence. Deviations inform
  the approver and never block; a run with none says so explicitly.
- A root `LICENSE.txt` carrying the PolyForm Noncommercial 1.0.0 text that
  every file header already references.
- `[container] selinux_relabel` makes ADORE usable on a host with SELinux
  enforcing, the default on Fedora, RHEL, CentOS Stream, Rocky and Alma.
  `docker/README.md` already named the requirement, but the four bind mounts
  were composed as bare `source:target` and no configuration could add a
  relabel suffix, so those hosts denied the container every read and each stage
  failed on permission denied. `shared` now appends `z` to the host bind mounts
  only - clone, worktree, run io directory, and the generated egress-proxy
  config, which becomes `ro,z` - while the named cache volumes stay untouched
  because the runtime already labels them. The default stays `off`, so Windows,
  WSL and Ubuntu profiles are unchanged. The private `Z` label is refused by
  both configuration validation and the `ContainerManager` constructor: it
  labels content with a per-container category, and the repository clone is
  shared by every run and by host git, so `Z` would bind the clone to whichever
  container mounted it first and break the next run.

## [0.13.0] - 2026-09-12

### Changed

- **ADORE's release number tracks the AEGIS line it was verified against**:
  this release jumps from 0.9.0 to 0.13.0, skipping 0.10.0, 0.11.0 and
  0.12.0, so the ADORE version names the newest AEGIS release the companion
  contract was re-proven on. The runtime still conducts the whole supported
  range (AEGIS major 0 at 0.5 or later); the number is a statement about
  verification, not a narrowing of compatibility.
- **ADORE conducts AEGIS 0.9.1 through 0.13.0 without a version-gate or
  parser change**, checked surface by surface against the AEGIS 0.13.0
  template. Re-verified unchanged: the `aegis <major>.<minor>.<patch>`
  version line (0.13.0 passes the major-0, floor-0.5 gate in
  `04_Software/adore/aegis.py`), JSON schema `1` on every payload, the
  `status` list and task documents (the new `interaction:` header key is an
  additive string the decoder already tolerates), the `check` document
  (`findings`/`summary`/`run`, `strict` only under `--strict`; an invalid
  `[interaction]` table arrives as an ordinary `config` finding), the
  single-path `task` creation output, the `report appended to `
  confirmation, and the `evolution` envelope, which changes only under the
  `--compact` flag ADORE never passes.
- One behavioral change closes the only supervision gap the new releases
  open: the executor stage prompt now declares every conducted task
  autopilot-to-deliver by explicit conductor instruction and has the
  executor record `interaction: autopilot` in the journal header. AEGIS
  0.13.0 makes checkpoint mode the default and stops before every stage
  transition, which ADORE would otherwise read as `NO_STAGE_PROGRESS` and
  fail after three attempts. The instruction is the per-task override AEGIS
  itself defines, so no target `aegis.toml` changes; frame keeps its
  path-selection sentence.
- What AEGIS 0.9.1 through 0.13.0 otherwise added falls outside ADORE's
  parsing boundary and is deliberately not modelled: the `trace` and
  `components` commands, `test --no-fallback` and `--dry-run`, the
  project-owned context scaffolds, the Routing-based component page
  template, the compact journal-ledger rules, and the optional host
  integrations for OpenCode, Pi, Codex, Qwen Code and Claude Code. Executors
  reach all of them through `AGENTS.md` like any other AEGIS feature, and
  ADORE's executors read `AGENTS.md` natively inside their container.
  Surfacing summaries, deviations and review verdicts at the approval gate
  remains open work, tracked in `.agentic/tasks/TASK-9aebe1f3.md`.
- Refreshed this repository's own `.agentic/` companion to AEGIS 0.13.0,
  preserving repository configuration and engineering history. The
  companion governs how ADORE is developed and does not ship in the runtime
  bundle.

### Removed

- `AegisClient.anchor()` and `AegisClient.test()`. No orchestrator path
  called them: the executor runs `anchor` and `test` itself during build and
  validate, and ADORE's own verification goes through `check --strict --run`.
  The client now carries only the operations the conductor issues, which is
  the surface re-verified on every AEGIS release.

## [0.9.0] - 2026-08-31

### Changed

- **ADORE's release number now tracks the AEGIS line it was verified
  against**: this release jumps from 0.7.0 directly to 0.9.0, deliberately
  skipping 0.8.0, so the ADORE version names the newest AEGIS release the
  companion contract was re-proven on. The runtime still conducts the whole
  supported range (AEGIS major 0 at 0.5 or later); the aligned number is a
  statement about verification, not a narrowing of compatibility.
- **ADORE conducts the AEGIS 0.8/0.9 releases without a version-gate or parser
  change**, and as with 0.7 the claim was checked surface by surface against
  the AEGIS 0.9.0 template rather than asserted. Re-verified unchanged: the
  `aegis <major>.<minor>.<patch>` version line (0.9.0 passes the major-0,
  floor-0.5 gate in `04_Software/adore/aegis.py`), JSON schema `1` on every
  payload, the `status` list and task documents (the new `parent:` header key
  is additive and the decoder tolerates extra string header keys), the `check`
  document (`findings`/`summary`/`run`, `strict` only under `--strict`; new
  check ids such as `review-state` flow through as ordinary findings), the
  single-path `task` creation output, the `report appended to ` confirmation,
  and the untouched `anchor`/`evolution` envelopes.
- One behavioral change closes the only supervision gap the new features open:
  the executor stage prompt now forbids creating child task journals
  (`task --parent`) in conducted runs. ADORE pins exactly one active task and
  reads only it, so executor work in a child journal would be invisible to
  stage supervision and end in a misleading `NO_STAGE_PROGRESS` failure;
  coordination is the conductor's job, not the executor's.
- What AEGIS 0.8.0 and 0.9.0 otherwise added falls outside ADORE's parsing
  boundary and is deliberately not modelled: the `summary` and `brief`
  commands are not called by the orchestrator (executors reach them through
  `AGENTS.md` like any other AEGIS command); the stage-report, rulings, and
  handoff journal sections are not decoded and do not appear in the status
  JSON; and `[review]` verdict policy belongs to the target repository, whose
  problems reach ADORE generically as check findings. Surfacing summaries,
  deviations, and review verdicts at the approval gate remains open work,
  tracked in `.agentic/tasks/TASK-9aebe1f3.md`.

## [0.7.0] - 2026-08-22

### Changed

- **ADORE conducts the whole AEGIS 0.7 line without a code change**, and that
  claim is now checked rather than asserted. Every contract surface the client
  depends on was re-verified against AEGIS 0.7.2: the `aegis <major>.<minor>.<patch>`
  version line, JSON schema `1` on every payload, the `status` list and task
  document (`header`, `stage`, `step_file`, `done`, `checklist`, `log`), the
  `check` document (`findings`/`summary`/`run`, and `strict` present only under
  `--strict`), and the `report appended to ` confirmation. All unchanged, so
  the version gate in `04_Software/adore/aegis.py` — major 0, floor 0.5 — needed
  no edit. This is the payoff of the 0.6.0 change that replaced the exact-minor
  pin with a major-plus-floor range.
- What AEGIS 0.7.1 and 0.7.2 did add falls outside ADORE's parsing boundary and
  is deliberately not modelled: the new `diagram` and `explain` commands are not
  called by the orchestrator (executors reach them through `AGENTS.md` like any
  other AEGIS command); the reworked `coverage_class` precedence changes which
  findings `check` emits, not the shape ADORE decodes; and the tightened
  `DEVIATION <stage>:` marker is read by AEGIS alone — `04_Software/` has no
  notion of deviations yet. Surfacing them at the approval gate remains open
  work, tracked in `.agentic/tasks/TASK-9aebe1f3.md`.
- Documentation now states the real AEGIS compatibility contract — major 0 at
  0.5 or later, JSON schema 1 — where it previously implied a hard 0.5.x pin
  (`04_Software/README.md`, `config.example.toml`, and the aegis-client
  knowledge page). No documentation names an AEGIS version, so a companion
  release no longer dates the prose.
- Refreshed this repository's own `.agentic/` companion to AEGIS 0.7.2, which
  also narrows AEGIS's scope to software development operations: version
  assignment and release-package construction — this release included — now
  follow the repository's own procedures rather than opening a task journal.
  The companion governs how ADORE is developed and does not ship in the runtime
  bundle.

## [0.6.0] - 2026-08-18

### Changed

- **ADORE no longer pins an AEGIS minor.** The old `SUPPORTED_SERIES = (0, 5)`
  demanded an exact minor, so every AEGIS release broke conduction until ADORE
  was edited in dozens of files. The gate is now a major plus a floor:
  `SUPPORTED_MAJOR = 0` and `MINIMUM_SERIES = (0, 5)`. Any AEGIS `0.y.z` at
  `0.5.0` or newer is conducted, so an AEGIS minor release needs no ADORE
  change at all.
- The floor is not cosmetic: `anchor` and `evolution` arrived in AEGIS 0.5.0
  and this client calls both, so a bare major check would accept a 0.4.x
  payload and then fail partway through a task. The floor turns that into an
  honest refusal at probe. A different major is still refused outright,
  because a major bump is the signal that the companion contract changed.
- `doctor` no longer keeps its own version pattern. It had a second, private
  regex that silently went stale whenever the client's range moved; it now
  derives the answer from the client's constants, so the setup probe and the
  orchestrator can never disagree about what is supported.
- Documentation, doctor guidance, the wizard report, and the executor stage
  prompt no longer name an AEGIS version at all. The supported range is
  declared once, in `adore/aegis.py`, and rendered from those constants where
  an operator needs to read it.
- **BREAKING: the ADORE run-state schema is renumbered from `4` to `1`,** so it
  reads alongside the AEGIS JSON schema instead of carrying the count forward
  from superseded ADORE lines. The number describes the shape of `state.json`
  only and is independent of any ADORE release. Existing schema-4 state is not
  migrated and is refused on load; delete the state root and start fresh. The
  diagnostics now render the number from the constant rather than repeating it
  in prose, so it cannot drift again.
- The superseded-implementation narrative is gone. Documentation, docstrings,
  operator guidance and tests no longer disclaim an earlier ADORE or AEGIS
  line, describe themselves as a "hard break", or promise not to migrate a
  contract nobody runs. The prose states what is supported; anything else is
  refused, and that is the whole rule.
- ADORE's own `.agentic/` payload is upgraded to AEGIS 0.6.0, so the repository
  is governed by the same series it conducts. That payload adds deviation
  notices: an agent states an anomaly in the conversation as a
  `DEVIATION <stage>:` line the moment it records one. ADORE reads the
  schema-1 JSON contract only and is unaffected by it - the notice adds no
  command, no schema field, and no journal change.

### Fixed

- AEGIS invocation timeouts now become retry-budgeted `AEGIS_TIMEOUT` stage
  failures, and clarification expiry uses the validated shared duration parser.
- Clarification resume, review revision, and approval invalidation now restart
  the active wall-clock phase without resetting cumulative budgets; approval
  invalidation also clears stale per-stage failures before re-conduction.
- Container-bound AEGIS calls now use a bounded, shell-quoted file exchange so
  spaced or shell-sensitive ticket text never crosses WSL-wrapped runtime argv,
  while pre-script failures preserve bounded runtime exit diagnostics.
- Executor timeout classification now follows the command runner's typed
  `timed_out` signal instead of guessing from stderr text.
- Human merges now count in aggregate, profile, and dashboard success metrics.
- Cleanup preserves live/unknown locks, operator mutations share the
  single-conductor lock, and `run --once` gives lock advice only for typed lock
  contention.
- Repository probing accepts AEGIS 0.5 adoption stages while active ADORE task
  decoding remains restricted to the seven conduction stages.
- Clarification handoffs are consumed once and removed after durable posting;
  closed source tickets cancel waiting/open-review runs without overriding an
  authoritative terminal MR/PR, while ticket text drift refreshes the persisted
  snapshot with a visible journal/resume note.
- Publication retry rechecks approval, adopts existing open branch MRs/PRs, and
  preserves close-out checkpoint/push recovery for already-done tasks.
- Review intent is consumed only after new-task creation, and terminal status
  replay no longer overwrites a cancelled, done, or failed lifecycle/outcome.
- Cleanup now protects failed-run worktrees, containers and evidence for retry,
  while sweeping exact-prefix orphan executor/proxy containers and egress
  networks with separate report fields even after allowlist mode changes.
- Ticket task-kind selection honors configured feature mappings before
  `workflow.default_kind`, and each budget check reads durable cost only once.
- CLI engine construction now prefers `.env` beside the resolved config,
  falls back to cwd, preserves process-environment precedence, and continues
  to inject only configured executor keys.

### Changed

- Metrics terminal classification now contains only runtime-emitted `done`,
  `failed`, and `cancelled`; the unused worktree commit-count API was removed.
- GitLab/GitHub wizard hosting/URL/visibility prompts were removed. Guidance now
  states that the platform CLI's active/default authenticated host controls
  corporate routing; Gitea retains explicit tea login selection.
- Operator guidance now states that conduction is serial, approval/review have
  no timers by design, failed resources require explicit cancel/delete to
  release, and the repository status describes the current ADORE/AEGIS 0.6
  companion-CLI contract.
- Container lifecycle documentation now states that parked containers are
  stopped and retained for resume or explicit cleanup boundaries.

## [0.5.0] - 2026-08-14

### Added

- Durable schema-4 run state for active and historical AEGIS task journals,
  stage-scoped failure history, validation evidence, candidate fingerprints,
  approval transitions, marker-owned incidents, and a required-notification
  outbox with idempotent ticket/MR replay and deleted-MR fallback.
- Configurable stage and transient recovery limits with defaults of three
  total failed attempts per stage and backoff `[5, 30, 120]`, plus the fresh
  delivery approval label protocol (`agent-approved`).
- Forge-agnostic MR/PR comment create/edit operations for GitHub, GitLab and
  Gitea, and product-diff/candidate fingerprint support in isolation.

### Changed

- The ADORE release identity is intentionally synchronized with its supported
  AEGIS line: ADORE `0.5.0` conducts AEGIS `0.5.x` only.
- **BREAKING: ADORE now supports only AEGIS 0.5.x JSON schema 1.** The grouped
  AEGIS 3.x client, run graph, waiver, schema-3 evidence and delegated
  stage-close behavior are removed. There is no compatibility or migration
  layer for unfinished ADORE 3.x state.
- One ticket now owns a task branch/worktree/container and one or more AEGIS
  `TASK-<id>` journals. Executors own journal stages; ADORE independently
  checks transitions, integrates the target, runs strict verification,
  checkpoints every successful stage locally, and owns all Git/forge writes.
- Publication requires a fresh post-presentation approval label bound to the
  exact candidate and target. Revisions create new AEGIS tasks on the same
  branch and require revalidation plus fresh approval. Publication remains
  draft-only and ADORE still never merges.

### Fixed

- Autonomous work can no longer remain silently stuck. Recoverable failures
  update a durable incident and the third failed attempt aborts; protocol,
  state, containment, policy and global-budget failures abort immediately.
  Notification failure itself stops work and remains queued for poll replay.

- Operator documentation now describes the AEGIS 0.5 hard-break contract,
  Gitea support, journal-stage ownership, fail-loud recovery, approval
  freshness, current defaults, and the released 0.5.0 identity consistently.

